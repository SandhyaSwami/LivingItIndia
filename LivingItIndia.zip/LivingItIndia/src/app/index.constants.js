/* global malarkey:false, moment:false */
(function() {
  'use strict';

  angular
    .module('livingItIndia')
    //.constant('malarkey', malarkey)
    //.constant('moment', moment);

})();
